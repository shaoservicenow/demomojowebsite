chrome.runtime.onInstalled.addListener(() => {
    console.log("DemoMojo installed!");
  });
  